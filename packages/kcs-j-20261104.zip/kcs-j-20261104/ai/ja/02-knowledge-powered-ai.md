# ナレッジを動力とするAI（Knowledge-Powered AI）

> 出典: Consortium for Service Innovation, *Knowledge-Powered AI* — ページにクリエイティブ・コモンズの表示なし（© Consortium for Service Innovation）。原文を日本語に翻訳したもの  
> 元のページ:
> - [Knowledge-Powered AI](https://www.serviceinnovation.org/knowledge-powered-ai/)

Consortiumのメンバーは、ナレッジを動力とするAIの機能の活用で最前線にいる。

![AI Powered by Knowledge](../../images/web-ai-only-logo-wordpress.png)

*図：「AI Powered by Knowledge（ナレッジを動力とするAI）」のロゴ。白抜きの画像なので、白い背景では見えない。*

AIの成果の良し悪しは、AIが引き出すナレッジの良し悪しで決まる。AIをうまく拡大するには、信頼できるコンテンツ、一貫した構造、キュレーションと再利用のための明確なワークフローが必要である。[KCS](https://www.serviceinnovation.org/kcs/)を実践してきた組織は、AIの力を活かすうえで独自の有利な立場にある。

Consortiumのメンバーは、ナレッジマネジメントの実践に加えて、明確な目的を定めること、事業部門の賛同を得ること、適切な資源を確保することも成功に必要だと結論付けている。

## AIの導入：課題と戦略

AIのテクノロジーが組織に何をもたらしうるかという華やかな面に目を向けたくなるが、Boston Consulting Group の調査結果は、AIの導入を成功させるには、AIモデルに10%、テクノロジーに20%、業務の変革に70%の比重を置くことが重要だと示している。

データとテクノロジーも重要だが、成功にとって最も決定的な要因は*業務の変革*である。

![10% AI Models, 20% Technology, 70% Operational Transformation](../../images/web-Screen-Shot-2024-08-22-at-9.29.14-PM-1024x713.png)

*図：AI導入の成功に向けた比重（Boston Consulting Group）。AIモデル（アルゴリズム、生成AI）10%、テクノロジー／IT（データ基盤、データの質と入手しやすさ、可視化ツール）20%、業務の変革（業務プロセス／ユースケース、人材とスキル、チェンジマネジメント、コミュニケーション）70%。*

*これは、体系的なAIの導入を進めてきたConsortiumのメンバーの経験とも一致する。私たちが学んできたことの詳細は次のとおり。*

- **[AI Implementation Essentials](01-ai-implementation-essentials.md)（AI導入の要点）：** 成功に何が必要かの概要
- [**AI Case Studies**](03-ai-case-studies.md)（AIの事例）：メンバーが実際にどうAIを導入しているか
- **[AI Blueprint](https://library.serviceinnovation.org/wiki/Featured_Member_Resources/AI_Blueprint)：** 詳しい例とテンプレートを含む、メンバー限定の資料

## AIの全体像：これから向かう先

私たちは、メンバー企業やその他の業界団体の業務上の経験に基づいて、構造化された取り組み方を提供し、ベストプラクティスを共有することで、組織がAIの誇大な宣伝から現実へと移るのを助けている。

[YouTube で「The AI Landscape | Part 2 of 2 | Where We Are Going」を見る](https://youtu.be/fEGfVAvVmeI)

*これは2部構成の第2部である。第1部はこちら* – [The AI Landscape: Where We Have Been](https://www.serviceinnovation.org/navigating-the-ai-landscape/)

## AIが動かす未来に加わる

Consortiumのメンバーは、業務プロセス、利用場面、業務の変革に焦点を当てた、よく考えられたAI導入の取り組みを続けている。会話に加わろう。

- [Consortiumのメーリングリスト](https://www.serviceinnovation.org/mailing-list/)に登録する
- [イベント](https://www.serviceinnovation.org/events)に参加する
- [Consortiumのメンバー](https://www.serviceinnovation.org/member-activities/)になる

### メンバー限定の資料

- [AI Blueprint](https://library.serviceinnovation.org/wiki/Featured_Member_Resources/AI_Blueprint)：詳しい例とテンプレートを含む実践ガイド
- Consortiumのメンバー用 Slack の [\#ml-llm-ai チャンネル](https://consortiummembers.slack.com/archives/C04S5QT3B6Y)に参加する
- [Thoughtful and Strategic Automation](https://library.serviceinnovation.org/wiki/Predictive_Customer_Engagement/Thoughtful_and_Strategic_Automation_Team_Meeting_2024)
- [The Intersection of ML-LLM-AI and KCS](https://library.serviceinnovation.org/wiki/KCS/Team_Meetings/ML-LLM-AI_and_KCS_Team_Meeting_2024)

[Consortiumのメンバー](https://www.serviceinnovation.org/current-members/)でログインに助けが必要な場合は、[support@serviceinnovation.org](mailto:support@serviceinnovation.org) に連絡すること。

## 出典の表示（Attribution）

KCS^(®)の方法論は、Consortium for Service Innovation のサービスマークである。

文書でKCSに初めて言及するときは、上付きの^(®)を付けなければならない。また、次の文を脚注または括弧書きで添えること：「KCS® is a service mark of the Consortium for Service Innovation^(TM).」

KCSは形容詞として使うのが正しい。例えば「[会社名] は KCS® の方法論を支持している……」のように使う。

Consortium for Service Innovation の書面による明示的な許可なく、KCSを提供物の名称に使うことはできない。質問は [Consortium へ問い合わせる](mailto:info@serviceinnovation.org) こと。
